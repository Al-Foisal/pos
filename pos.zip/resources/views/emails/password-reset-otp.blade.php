<x-mail::message>
# Password Rest Otp

Your password reset OTP is {{ $otp }}

Thanks,<br>
{{ $company->name }}
</x-mail::message>